package com.example.JOBNOVA.service;



import com.example.JOBNOVA.model.Internship;
import com.example.JOBNOVA.repository.InternshipRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class InternshipService {
    private final InternshipRepository repo;
    public InternshipService(InternshipRepository repo) { this.repo = repo; }

    public List<Internship> all() { return repo.findAll(); }
}

