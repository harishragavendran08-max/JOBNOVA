package com.example.JOBNOVA.controller;

import com.example.JOBNOVA.model.Job;
import com.example.JOBNOVA.service.JobService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/jobs")
public class JobController {
    private final JobService service;

    public JobController(JobService service) {
        this.service = service;
    }

    @GetMapping
    public List<Job> all() {
        return service.all();
    }

    @GetMapping("/search")
    public List<Job> search(@RequestParam String skill) {
        return service.searchBySkill(skill);
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> create(@Valid @RequestBody Job payload) {
        Job created = service.save(payload);
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of("job", created));
    }
}
