package com.example.JOBNOVA.service;



import com.example.JOBNOVA.model.Certification;
import com.example.JOBNOVA.repository.CertificationRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CertificationService {
    private final CertificationRepository repo;
    public CertificationService(CertificationRepository repo) { this.repo = repo; }

    public List<Certification> all() { return repo.findAll(); }
}
