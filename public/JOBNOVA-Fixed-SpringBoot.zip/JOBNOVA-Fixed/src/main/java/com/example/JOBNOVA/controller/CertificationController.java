package com.example.JOBNOVA.controller;

import com.example.JOBNOVA.model.Certification;
import com.example.JOBNOVA.service.CertificationService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/certifications")
@CrossOrigin(origins = "*")
public class CertificationController {

    private final CertificationService service;

    public CertificationController(CertificationService service) {
        this.service = service;
    }

    @GetMapping
    public List<Certification> all() {
        return service.all();
    }
}
