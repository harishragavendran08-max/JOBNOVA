package com.example.JOBNOVA.repository;


import com.example.JOBNOVA.model.Internship;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InternshipRepository extends JpaRepository<Internship, Long> {
    // Default CRUD operations are automatically available
}

