package com.example.JOBNOVA.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String oauthId;

    @NotBlank(message = "Please enter your full name (at least 2 characters).")
    @Size(min = 2, max = 80, message = "Please enter your full name (at least 2 characters).")
    private String name;

    @NotBlank(message = "Please enter a valid email address.")
    @Email(message = "Please enter a valid email address.")
    private String email;

    private String headline;
    private String location;
    private String summary;

    @ElementCollection
    private List<String> skills;

    private String profileImage;
}
