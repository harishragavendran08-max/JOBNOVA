package com.example.JOBNOVA.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "jobs")
public class Job {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Job title, company, and skills are required.")
    @Size(min = 3, max = 120, message = "Job title must be between 3 and 120 characters.")
    private String title;

    @NotBlank(message = "Job title, company, and skills are required.")
    @Size(min = 2, max = 80, message = "Company name must be between 2 and 80 characters.")
    private String company;

    @NotBlank(message = "Job location cannot be blank.")
    private String location;

    private String description;

    @NotBlank(message = "Job title, company, and skills are required.")
    @Size(min = 2, max = 255, message = "Required skills must be between 2 and 255 characters.")
    private String skills;

    private String ctc;

    @Email(message = "Recruiter contact email must be a valid email address.")
    private String recruiterEmail;
}
