package com.example.JOBNOVA.controller;

import jakarta.validation.Valid;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    public record LoginRequest(
        @NotBlank(message = "Please enter your email address.")
        @Email(message = "Please enter a valid email address (e.g., name@domain.com).")
        String email,

        @NotBlank(message = "Please enter your password.")
        @Size(min = 6, max = 100, message = "Password must be at least 6 characters long.")
        String password
    ) {}

    public record SignUpRequest(
        @NotBlank(message = "Please enter your full name (at least 2 characters).")
        @Size(min = 2, max = 80, message = "Please enter your full name (at least 2 characters).")
        String name,

        @NotBlank(message = "Please enter a valid email address.")
        @Email(message = "Please enter a valid email address.")
        String email,

        @NotBlank(message = "Password must be at least 8 characters long.")
        @Size(min = 8, max = 100, message = "Password must be at least 8 characters long.")
        @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d).+$", message = "Password must include at least one letter and one number.")
        String password,

        String confirmPassword,
        String trackId,
        String location,

        @AssertTrue(message = "Please accept the JobNova Terms of Service to create your account.")
        boolean acceptTerms
    ) {}

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(Map.of(
            "authenticated", true,
            "email", request.email()
        ));
    }

    @PostMapping("/signup")
    public ResponseEntity<Map<String, Object>> signUp(@Valid @RequestBody SignUpRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
            "authenticated", true,
            "name", request.name(),
            "email", request.email()
        ));
    }
}
