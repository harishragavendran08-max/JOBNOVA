package com.example.JOBNOVA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobnovaApplicationTests {

	@Test
	void contextLoads() {
	}

}
