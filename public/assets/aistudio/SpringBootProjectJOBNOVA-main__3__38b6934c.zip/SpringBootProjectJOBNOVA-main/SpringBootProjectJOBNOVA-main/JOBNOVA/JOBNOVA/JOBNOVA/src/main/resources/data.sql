-- ================= JOBS (Top Indian Companies) =================
INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (1, 'Software Engineer', 'TCS', 'Chennai', 'Develop enterprise Java & Spring Boot apps.', 'java,springboot,sql');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (2, 'Backend Developer', 'Infosys', 'Bengaluru', 'Work on REST APIs and microservices.', 'java,springboot,hibernate');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (3, 'Frontend Engineer', 'Wipro', 'Hyderabad', 'Build modern web interfaces.', 'html,css,javascript,react');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (4, 'Data Analyst', 'HCL', 'Noida', 'Analyze and visualize data using Python.', 'python,sql,pandas');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (5, 'AI Engineer', 'Google India', 'Bengaluru', 'Build and deploy ML models.', 'python,tensorflow,ai,ml');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (6, 'Cloud Engineer', 'Amazon India', 'Hyderabad', 'Manage AWS cloud infrastructure.', 'aws,cloud,linux,devops');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (7, 'Blockchain Developer', 'Accenture', 'Mumbai', 'Develop blockchain and smart contracts.', 'blockchain,solidity,web3');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (8, 'Full Stack Developer', 'Cognizant', 'Pune', 'Develop end-to-end applications.', 'java,html,css,javascript,mysql');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (9, 'Cybersecurity Analyst', 'Tech Mahindra', 'Chennai', 'Protect systems and networks.', 'cybersecurity,linux,networking');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (10, 'DevOps Engineer', 'IBM India', 'Bengaluru', 'CI/CD, automation and container orchestration.', 'jenkins,docker,kubernetes,aws');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (11, 'Mobile App Developer', 'Zoho', 'Chennai', 'Build Android and iOS apps.', 'flutter,kotlin,java');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (12, 'UI/UX Designer', 'Adobe India', 'Remote', 'Design clean, user-friendly interfaces.', 'uiux,figma,designthinking');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (13, 'Web Developer', 'Flipkart', 'Bengaluru', 'Create responsive websites.', 'html,css,bootstrap,js');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (14, 'Software Tester', 'Capgemini', 'Kolkata', 'Automate and test web apps.', 'selenium,java,testing');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (15, 'AI Research Intern', 'NVIDIA India', 'Pune', 'Work on AI vision and models.', 'python,pytorch,deeplearning');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (16, 'Web Application Developer', 'Oracle India', 'Bengaluru', 'Build scalable enterprise web apps.', 'java,jsp,servlet,spring');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (17, 'Game Developer', 'Unity Technologies', 'Hyderabad', 'Develop games using C# and Unity.', 'csharp,unity,3d');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (18, 'Marketing Analyst', 'Byjus', 'Bengaluru', 'Analyze and optimize marketing campaigns.', 'marketing,analytics,excel');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (19, 'Cloud Developer', 'Microsoft India', 'Hyderabad', 'Develop cloud-native applications.', 'azure,csharp,dotnet');

INSERT INTO JOB (id, title, company, location, description, skills)
VALUES (20, 'Data Engineer', 'Reliance Jio', 'Mumbai', 'Build data pipelines for analytics.', 'python,spark,hadoop,sql');

-- ================= INTERNSHIPS =================
INSERT INTO INTERNSHIP (id, title, company, location, description)
VALUES (1, 'Web Development Intern', 'TechNova', 'Remote', 'Assist in building front-end web apps using HTML, CSS, and JS.');

INSERT INTO INTERNSHIP (id, title, company, location, description)
VALUES (2, 'Java Backend Intern', 'TCS', 'Chennai', 'Develop REST APIs using Java and Spring Boot.');

INSERT INTO INTERNSHIP (id, title, company, location, description)
VALUES (3, 'Data Science Intern', 'Infosys', 'Remote', 'Analyze data using Python and ML algorithms.');

INSERT INTO INTERNSHIP (id, title, company, location, description)
VALUES (4, 'AI Chatbot Intern', 'Google India', 'Bengaluru', 'Integrate OpenAI chatbot models.');

INSERT INTO INTERNSHIP (id, title, company, location, description)
VALUES (5, 'UI/UX Intern', 'Adobe India', 'Remote', 'Design modern interfaces in Figma.');

INSERT INTO INTERNSHIP (id, title, company, location, description)
VALUES (6, 'Cybersecurity Intern', 'HCL', 'Noida', 'Assist in penetration testing and threat analysis.');

INSERT INTO INTERNSHIP (id, title, company, location, description)
VALUES (7, 'DevOps Intern', 'Wipro', 'Hyderabad', 'Work with Docker and CI/CD pipelines.');

INSERT INTO INTERNSHIP (id, title, company, location, description)
VALUES (8, 'Marketing Intern', 'Byjus', 'Remote', 'Assist in online marketing and campaign tracking.');

-- ================= COURSES (Basics → Advanced) =================
-- ==============================
-- COURSES (30 ENTRIES)
-- ==============================

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (1, 'HTML & CSS from Scratch', 'Coursera', 'https://coursera.org/learn/html-css', 'Learn to structure and style modern websites using HTML5 and CSS3.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (2, 'JavaScript Mastery', 'Udemy', 'https://udemy.com/course/javascript-mastery', 'Understand core JavaScript, ES6, and build interactive web apps.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (3, 'Complete Java Developer', 'Coursera', 'https://coursera.org/learn/java', 'Master Java programming for backend and enterprise systems.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (4, 'Python for Beginners', 'edX', 'https://edx.org/course/python-basics', 'Start coding in Python and learn data handling, loops, and OOP.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (5, 'Spring Boot Complete Guide', 'Udemy', 'https://udemy.com/course/spring-boot', 'Develop full-stack applications using Spring Boot and REST APIs.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (6, 'AI and Machine Learning Foundations', 'Coursera', 'https://coursera.org/learn/machine-learning', 'Explore supervised and unsupervised learning using Python.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (7, 'C Programming Fundamentals', 'Udemy', 'https://udemy.com/course/c-programming', 'Learn how to code in C for system and embedded programming.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (8, 'C++ Masterclass', 'Coursera', 'https://coursera.org/learn/cpp', 'Object-oriented programming and problem-solving using C++.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (9, 'Bootstrap 5 UI Design', 'Coursera', 'https://coursera.org/learn/bootstrap', 'Design stunning and responsive websites using Bootstrap.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (10, 'AWS Cloud Practitioner Essentials', 'Amazon AWS', 'https://aws.amazon.com/training/', 'Understand AWS cloud architecture, IAM, and deployment.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (11, 'MySQL Database Design', 'Udemy', 'https://udemy.com/course/mysql-database', 'Learn relational database design, normalization, and SQL.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (12, 'PHP & Laravel for Web Development', 'Udemy', 'https://udemy.com/course/php-laravel', 'Create robust PHP web applications using Laravel.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (13, 'Kotlin for Android Development', 'Google', 'https://developer.android.com/kotlin', 'Develop modern Android apps with Kotlin and Jetpack.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (14, 'Rust Programming Language', 'edX', 'https://edx.org/course/rust', 'Build safe and high-performance systems using Rust.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (15, 'Servlets & JSP Advanced', 'Coursera', 'https://coursera.org/learn/jsp-servlet', 'Develop dynamic Java web apps with Servlets and JSP.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (16, 'UI/UX Design for Beginners', 'Google UX', 'https://coursera.org/professional-certificates/google-ux-design', 'Learn visual design, research, and usability testing.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (17, 'Digital Marketing Masterclass', 'edX', 'https://edx.org/course/digital-marketing', 'Learn SEO, SEM, social media, and Google Ads.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (18, 'Blockchain Essentials', 'Coursera', 'https://coursera.org/learn/blockchain-basics', 'Understand blockchain concepts, crypto, and smart contracts.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (19, 'Cybersecurity Fundamentals', 'IBM SkillsBuild', 'https://skillsbuild.org', 'Learn how to identify and mitigate security threats.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (20, 'Cloud Computing with Microsoft Azure', 'Microsoft Learn', 'https://learn.microsoft.com/en-us/training/azure/', 'Build and deploy scalable apps on Azure Cloud.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (21, 'Data Structures & Algorithms in Java', 'GeeksforGeeks', 'https://practice.geeksforgeeks.org/courses/dsa', 'Master problem solving and competitive programming.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (22, 'DevOps with Docker and Jenkins', 'Udemy', 'https://udemy.com/course/devops-docker-jenkins', 'Build CI/CD pipelines and automate deployments.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (23, 'ReactJS & Modern Frontend', 'Coursera', 'https://coursera.org/learn/reactjs', 'Learn component-based development and React hooks.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (24, 'Angular Framework Crash Course', 'Udemy', 'https://udemy.com/course/angular-crash-course', 'Develop scalable single-page web applications with Angular.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (25, 'Flutter App Development', 'Google', 'https://flutter.dev/learn', 'Build cross-platform apps for Android and iOS using Flutter.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (26, 'Artificial Intelligence in Business', 'edX', 'https://edx.org/course/ai-business', 'Use AI tools and automation for business solutions.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (27, 'Big Data & Hadoop Fundamentals', 'Coursera', 'https://coursera.org/learn/big-data', 'Learn data engineering using Hadoop and Spark.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (28, 'Ethical Hacking & Penetration Testing', 'Udemy', 'https://udemy.com/course/ethical-hacking', 'Learn hacking techniques and cybersecurity defense.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (29, 'AI with ChatGPT & OpenAI API', 'Udemy', 'https://udemy.com/course/chatgpt-openai', 'Integrate AI APIs to build smart applications.');

INSERT INTO COURSE (id, title, provider, url, description)
VALUES (30, 'Career Growth & Soft Skills', 'LinkedIn Learning', 'https://linkedin.com/learning', 'Develop communication, teamwork, and leadership skills.');

-- ================= CERTIFICATIONS =================
INSERT INTO CERTIFICATION (id, name, issuer, credential_url)
VALUES (1, 'Java SE 11 Developer', 'Oracle', 'https://education.oracle.com/java-se-11-developer');

INSERT INTO CERTIFICATION (id, name, issuer, credential_url)
VALUES (2, 'AWS Certified Cloud Practitioner', 'Amazon', 'https://aws.amazon.com/certification/');

INSERT INTO CERTIFICATION (id, name, issuer, credential_url)
VALUES (3, 'Google Data Analytics Certificate', 'Google', 'https://grow.google/certificates/data-analytics');

INSERT INTO CERTIFICATION (id, name, issuer, credential_url)
VALUES (4, 'Microsoft Azure Fundamentals', 'Microsoft', 'https://learn.microsoft.com/en-us/certifications');

INSERT INTO CERTIFICATION (id, name, issuer, credential_url)
VALUES (5, 'Python Programming Professional Certificate', 'Coursera', 'https://coursera.org/professional-certificates/python');

INSERT INTO CERTIFICATION (id, name, issuer, credential_url)
VALUES (6, 'Cybersecurity Analyst Professional', 'IBM', 'https://www.ibm.com/training/cybersecurity');

INSERT INTO CERTIFICATION (id, name, issuer, credential_url)
VALUES (7, 'Spring Framework Developer', 'VMware', 'https://spring.io/certification');
