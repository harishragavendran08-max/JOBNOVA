async function fetchJSON(url) {
  const res = await fetch(url);
  return res.json();
}

// Run this when any page loads
window.addEventListener('load', async () => {
  // 1. Homepage job list
  const jobList = document.getElementById('jobs-list');
  if (jobList) {
    const jobs = await fetchJSON('/api/jobs');
    jobList.innerHTML = jobs.map(j =>
      `<div class="job"><b>${j.title}</b> @ ${j.company}<br>${j.location}</div>`
    ).join('');
  }

  // 2. Profile page
  const profile = document.getElementById('profile');
  if (profile) {
    try {
      const me = await fetchJSON('/api/user/me');
      profile.innerText = JSON.stringify(me, null, 2);
    } catch (e) {
      profile.innerText = 'Please log in to view profile.';
    }
  }



  // 3. Learning page
  const coursesContainer = document.getElementById('courses');
  if (coursesContainer) {
    let allCourses = [];

    async function loadCourses() {
      try {
        const list = await fetchJSON('/api/courses');
        allCourses = list;
        displayCourses(list);
      } catch (err) {
        console.error('Error fetching courses:', err);
        coursesContainer.innerHTML = '<p>⚠️ Unable to load courses. Please try again later.</p>';
      }
    }

    function displayCourses(list) {
      if (!list.length) {
        coursesContainer.innerHTML = '<p>No courses found 😕</p>';
        return;
      }

      coursesContainer.innerHTML = list.map(c => `
        <div class="course-card">
          <h3>${c.title}</h3>
          <div class="provider">🎓 ${c.provider}</div>
          <p class="description">${c.description}</p>
          <a href="${c.url}" target="_blank" class="learn-btn">Start Learning</a>
        </div>
      `).join('');
    }

    // Search bar functionality
    window.searchCourses = function () {
      const keyword = document.getElementById('search').value.toLowerCase();
      const filtered = allCourses.filter(c =>
        c.title.toLowerCase().includes(keyword) ||
        c.description.toLowerCase().includes(keyword) ||
        c.provider.toLowerCase().includes(keyword)
      );
      displayCourses(filtered);
    };

    // Load on page start
    loadCourses();
  }


  // 4. Certifications page
  const certs = document.getElementById('certs');
  if (certs) {
    const list = await fetchJSON('/api/certifications');
    certs.innerHTML = list.map(c =>
      `<div class="job"><b>${c.name}</b> - ${c.issuer}</div>`
    ).join('');
  }

  // 5. Internships page
  const interns = document.getElementById('interns');
  if (interns) {
    const list = await fetchJSON('/api/internships');
    interns.innerHTML = list.map(i =>
      `<div class="job"><b>${i.title}</b> @ ${i.company}<br>${i.location}</div>`
    ).join('');
  }
});

// Job search
async function search() {
  const skill = document.getElementById('skill').value;
  const res = await fetch('/api/jobs/search?skill=' + encodeURIComponent(skill));
  const jobs = await res.json();
  document.getElementById('jobs').innerHTML = jobs.map(j =>
    `<div class="job"><b>${j.title}</b> @ ${j.company}<br>${j.skills}</div>`
  ).join('');
}

// Simple AI assistant call
async function askGemini() {
  const prompt = document.getElementById('prompt').value;
  const responseElement = document.getElementById('response');

  if (!prompt.trim()) {
    responseElement.innerText = "⚠️ Please type something.";
    return;
  }

  responseElement.innerText = "🤔 Thinking...";

  try {
    const res = await fetch("http://localhost:8080/api/ai/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt })
    });

    const data = await res.json();
    responseElement.innerText = data.response || "⚠️ No response received.";
  } catch (error) {
    console.error(error);
    responseElement.innerText = "⚠️ Server error. Showing offline tips:\n" +
      "Keep your resume short, clear, and focused on measurable results.";
  }
}
