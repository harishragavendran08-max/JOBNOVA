package com.example.JOBNOVA.JOBNOVA.repository;


import com.example.JOBNOVA.JOBNOVA.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    // Find user by email (used for login)
    Optional<User> findByEmail(String email);

    // Find user by OAuth2 provider ID
    Optional<User> findByOauthId(String oauthId);
}
