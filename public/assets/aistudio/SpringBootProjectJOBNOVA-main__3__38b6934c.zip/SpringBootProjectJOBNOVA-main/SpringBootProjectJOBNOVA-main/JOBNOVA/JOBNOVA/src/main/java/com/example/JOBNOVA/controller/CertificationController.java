package com.example.JOBNOVA.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/certifications")
public class CertificationController {
    private final CertificationController service;
    public CertificationController(CertificationController service) { this.service = service; }

    @GetMapping
    public Object all() { return service.all(); }
}
